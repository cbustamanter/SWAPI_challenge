module.exports = Object.freeze({
    SWAPI_URL: 'http://swapi.py4e.com/api',
});