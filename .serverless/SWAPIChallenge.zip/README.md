# TCS Challenge
Repositorio para el reto técnico de TCS.

## Tecnologías usadas
    - NodeJS 14.x
    - AWS-Serverless
    - Serverless (as DEV Dependency)
    - Axios
    - RDS MySQL

## Documentación de rutas
#### *People API*
 - ```api/v1/people/:id``` obtiene *people* por id
 - ```api/v1/people/``` obtiene lista de *people*

#### *Planets API*
 - ```api/v1/planets/:id``` obtiene *planet* por id
 - ```api/v1/planets/``` obtiene lista de *planets*